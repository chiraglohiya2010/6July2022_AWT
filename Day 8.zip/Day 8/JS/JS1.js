function my() {
    alert('hello');
}
console.log('hello i am datt patel');
function e()
{
    document.body.style.backgroundColor=prompt('enter the color');

}
function r(){
    document.getElementById('d').style.backgroundColor="red";
}
function n(){
    document.getElementById('w').style.backgroundColor="blue";

}
function p(){
    document.body.style.backgroundColor=document.getElementById('q').value;
}
function a(){
    document.getElementById('u').style.backgroundColor=document.getElementById('o').value;;

}
function f1(){
    var vn1= prompt("enter name");
    document.getElementById('text').innerHTML = vn1;
}
function ch1()
{
    var ko=prompt("Enter First Name")
    var ki=prompt("Enter last name")
    document.getElementById('l').innerHTML = ko;
    document.getElementById('m').innerHTML = ki;
}